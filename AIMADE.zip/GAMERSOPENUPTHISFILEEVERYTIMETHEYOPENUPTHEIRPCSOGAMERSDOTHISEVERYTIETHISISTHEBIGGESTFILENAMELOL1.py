import tkinter as tk
import random

# Colors for the rainbow effect
colors = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"]

root = tk.Tk()
root.title("✨ Fun Rainbow Message ✨")
root.geometry("500x200")

message = "THIS IS A FUN RAINBOW MESSAGE 😄"

label = tk.Label(root, text="", font=("Arial", 20, "bold"))
label.pack(expand=True)

# Animate the rainbow text
def update_color():
    color = random.choice(colors)
    label.config(text=message, fg=color)
    root.after(200, update_color)

update_color()
root.mainloop()