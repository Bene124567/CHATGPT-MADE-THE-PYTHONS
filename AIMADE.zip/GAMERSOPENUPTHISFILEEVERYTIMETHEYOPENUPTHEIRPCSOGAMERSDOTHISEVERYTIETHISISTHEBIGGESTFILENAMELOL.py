import tkinter as tk
from tkinter import messagebox

def salinewin_popup():
    root = tk.Tk()
    root.title("Salinewin")

    # your icon file
    root.iconbitmap("icooftheidk.ico")

    root.withdraw()  # hide main window

    messagebox.showinfo("Salinewin", "This is a fake Salinewin message!")

    root.destroy()

salinewin_popup()