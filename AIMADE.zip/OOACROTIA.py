import os
import random
import time
import threading
import sys

# Try imports that may not exist on every system
try:
    import winsound
    HAS_WINSOUND = True
except:
    HAS_WINSOUND = False

try:
    import tkinter as tk
    from tkinter import messagebox
    HAS_TK = True
except:
    HAS_TK = False

# ===========================
# COMMON GLITCHING FUNCTIONS
# ===========================

colors = ["\033[91m","\033[92m","\033[93m","\033[94m","\033[95m","\033[96m"]
reset = "\033[0m"


def typewrite(text, speed=0.03):
    for c in text:
        print(c, end="", flush=True)
        time.sleep(speed)
    print()


def clear():
    os.system("cls" if os.name == "nt" else "clear")


# ===========================
# MODE 1 — SOUND GLITCH
# ===========================

def mode_sound():
    clear()
    typewrite("Starting SOUND glitch mode...\n", 0.04)

    if not HAS_WINSOUND:
        print("Your system doesn't support winsound, skipping beeps.\n")

    chars = "@#$%01GLITCH?"
    for _ in range(30):
        line = "".join(random.choice(chars) for _ in range(60))
        print(random.choice(colors) + line + reset)
        if HAS_WINSOUND:
            winsound.Beep(random.randint(200, 2000), random.randint(80, 200))
        time.sleep(0.05)

    print(reset + "\nSound glitch complete. Everything remained safe :)")
    input("\nPress Enter to return to menu...")


# ===========================
# MODE 2 — GUI GLITCH WINDOWS
# ===========================

def mode_gui():
    if not HAS_TK:
        print("tkinter not available on your system. Cannot run GUI mode.")
        input("\nPress Enter to return to menu...")
        return

    def spawn_window():
        w = tk.Toplevel()
        w.title("GLITCH")
        w.geometry(f"200x100+{random.randint(0,700)}+{random.randint(0,500)}")
        tk.Label(w, text=random.choice(["GL1TCH", "ERROR?", "???", "MEMZ??"]), fg="red").pack(expand=True)
        w.after(500, w.destroy)

    def spam():
        for _ in range(25):
            spawn_window()
            time.sleep(0.1)

    root = tk.Tk()
    root.title("Fake MEMZ GUI Edition")
    root.geometry("300x150")

    tk.Label(root, text="Fake MEMZ GUI Edition\n(Harmless)").pack()

    threading.Thread(target=spam, daemon=True).start()
    root.mainloop()


# ===========================
# MODE 3 — CHAOTIC TERMINAL
# ===========================

def mode_chaos():
    clear()
    print("Starting CHAOTIC TERMINAL GLITCH...\n")

    chars = "@#$%&*?!01GLITCH"
    for _ in range(200):
        line = "".join(random.choice(chars) for _ in range(100))
        print(random.choice(colors) + line + reset)
        time.sleep(0.01)

    print(reset + "\nChaotic glitch finished. Nothing bad happened :)")
    input("\nPress Enter to return to menu...")


# ===========================
# MODE 4 — POPUP PRANK
# ===========================

def mode_popup():
    if not HAS_TK:
        print("tkinter not available on your system. Cannot run popup mode.")
        input("\nPress Enter to return to menu...")
        return

    messages = [
        "Your PC is completely safe.",
        "This is just a prank.",
        "Relax, nothing is happening.",
        "You're fine.",
        "Fake MEMZ says hi.",
    ]

    def popup_loop():
        for _ in range(5):
            messagebox.showinfo("Fake MEMZ Popup", random.choice(messages))
            time.sleep(0.2)

    root = tk.Tk()
    root.withdraw()

    threading.Thread(target=popup_loop, daemon=True).start()
    root.mainloop()


# ===========================
# MAIN MENU
# ===========================

def main_menu():
    while True:
        clear()
        print("==== FAKE MEMZ ALL-IN-ONE (SAFE) ====\n")
        print("1. Sound Glitch Mode")
        print("2. GUI Glitch Windows")
        print("3. Chaotic Terminal Effect")
        print("4. Popup Prank")
        print("5. Exit\n")

        choice = input("Select a mode: ")

        if choice == "1":
            mode_sound()
        elif choice == "2":
            mode_gui()
        elif choice == "3":
            mode_chaos()
        elif choice == "4":
            mode_popup()
        elif choice == "5":
            clear()
            print("Goodbye!")
            sys.exit()
        else:
            print("Invalid option.")
            time.sleep(1)


if __name__ == "__main__":
    main_menu()