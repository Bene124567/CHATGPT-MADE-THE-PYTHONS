import tkinter as tk
from itertools import cycle

# Colors for rainbow effect
colors = cycle(["red", "orange", "yellow", "green", "blue", "indigo", "violet"])

def animate_text():
    color = next(colors)
    label.config(fg=color)
    root.after(200, animate_text)  # change color every 200ms

# Create main window
root = tk.Tk()
root.title("Fake BonziBuddy")
root.geometry("400x200")

# Set custom icon (replace with your .ico file path)
try:
    root.iconbitmap("icooftheidk.ico")
except Exception as e:
    print("Icon not found, using default icon.")

# Rainbow text label
label = tk.Label(root, text="Hello! I'm your fake BonziBuddy!", font=("Comic Sans MS", 16))
label.pack(expand=True)

animate_text()  # start rainbow animation

root.mainloop()