import tkinter as tk
from tkinter import messagebox
import time
import random
import sys
import itertools

# ---------- RAINBOW TERMINAL TEXT ----------
colors = [
    "\033[31m",  # red
    "\033[33m",  # yellow
    "\033[32m",  # green
    "\033[36m",  # cyan
    "\033[34m",  # blue
    "\033[35m",  # magenta
]
reset = "\033[0m"

def rainbow_text(text):
    out = ""
    for i, ch in enumerate(text):
        out += colors[i % len(colors)] + ch
    return out + reset

# ---------- ANIMATED TERMINAL EFFECT ----------
def rainbow_animation(text, repeat=1, delay=0.05):
    for _ in range(repeat):
        for c in itertools.cycle(colors):
            sys.stdout.write(c + text + reset + "\r")
            sys.stdout.flush()
            time.sleep(delay)
            break

# ---------- POPUP SECTION ----------
root = tk.Tk()
root.withdraw()

# Optional icon
try:
    root.iconbitmap("icoofidk.ico")
except:
    pass

popup_messages = [
    "🦠 Virus Simulator: Overheating the glitter processor...",
    "⚠️ Warning: Too much fabulous energy detected!",
    "✨ System Upgrade: Installing sparkles...",
    "❌ Critical Error: You are too awesome for this machine!",
    "💥 Data Explosion: Rainbow bytes leaking everywhere!",
]

popup_types = [
    messagebox.showerror,
    messagebox.showwarning,
    messagebox.showinfo
]

# ---------- THEMED SEQUENCE ----------
def popup_sequence(count=6):
    for _ in range(count):
        msg = random.choice(popup_messages)
        popup = random.choice(popup_types)
        popup("Virus Simulator 3000", msg)
        time.sleep(0.4)

# ---------- RUN THE SHOW ----------
print(rainbow_text("Welcome to Virus Simulator 3000!"))
rainbow_animation("🌈 Booting rainbow engine... ")

popup_sequence()

print(rainbow_text("✔ Operation complete. No viruses, only sparkles."))