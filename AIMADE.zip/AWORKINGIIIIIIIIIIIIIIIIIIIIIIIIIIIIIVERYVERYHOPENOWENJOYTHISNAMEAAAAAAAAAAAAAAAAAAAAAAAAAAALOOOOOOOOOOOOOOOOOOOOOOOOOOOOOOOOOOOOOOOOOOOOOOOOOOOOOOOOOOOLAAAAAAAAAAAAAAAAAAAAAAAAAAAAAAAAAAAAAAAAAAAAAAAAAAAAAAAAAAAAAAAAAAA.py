import tkinter as tk
import threading
import itertools
import time
import os

ICON_PATH = "anotherico.ico"

RAINBOW = [
    "#FF0000", "#FF7F00", "#FFFF00",
    "#00FF00", "#0000FF", "#4B0082",
    "#9400D3"
]

def popup(text):
    win = tk.Tk()
    win.title("Totally Not Malware 😈 (Harmless)")

    # Set icon if exists
    if os.path.exists(ICON_PATH):
        try:
            win.iconbitmap(ICON_PATH)
        except:
            pass

    win.geometry("380x160")

    label = tk.Label(win, text=text, font=("Arial", 18, "bold"))
    label.pack(expand=True)

    # Rainbow cycle animation
    def animate():
        for color in itertools.cycle(RAINBOW):
            try:
                label.config(fg=color)
                time.sleep(0.15)
            except tk.TclError:
                break

    threading.Thread(target=animate, daemon=True).start()
    win.mainloop()


def main():
    messages = [
        "Hello there 😎",
        "Fake malware booting…",
        "Just kidding, you're safe!",
        "Have a nice day ✨"
    ]

    for msg in messages:
        popup(msg)


if __name__ == "__main__":
    main()