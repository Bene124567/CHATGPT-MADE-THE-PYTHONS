import tkinter as tk
from tkinter import messagebox
import itertools
import time
import threading
import os

# try to load the custom icon if it exists
ICON_PATH = "anotherico.ico"

rainbow_colors = [
    "#FF0000", "#FF7F00", "#FFFF00",
    "#00FF00", "#0000FF", "#4B0082", "#8F00FF"
]

def colorful_popup(text):
    popup = tk.Tk()
    popup.title("NOT AI MADE THIS HE IS SMARTER")

    # set icon if file exists
    if os.path.exists(ICON_PATH):
        try:
            popup.iconbitmap(ICON_PATH)
        except Exception:
            pass

    popup.geometry("350x150")

    # rainbow label
    label = tk.Label(popup, text=text, font=("Arial", 16, "bold"))
    label.pack(expand=True)

    # change colors in a loop using a background thread
    def color_cycle():
        for color in itertools.cycle(rainbow_colors):
            try:
                label.config(fg=color)
                time.sleep(0.2)
            except tk.TclError:
                break  # window was closed

    threading.Thread(target=color_cycle, daemon=True).start()

    popup.mainloop()


def main():
    messages = [
        "Hello! ",
        "Fake malware activated!",
        "Don't panic, it's harmless ",
        ""EZ" "LOL"",
    ]

    for msg in messages:
        colorful_popup(msg)


if __name__ == "__main__":
    main()